<nav class="navigation nav">

	<?php wp_nav_menu( array(
		'container'       => 'ul', 
		'menu_class'      => 'sf-menu mobile-menu', 
		'menu_id'         => 'primary',
		'depth'           => 0,
		'theme_location'  => 'header_menu' 
	));?>
	
</nav>