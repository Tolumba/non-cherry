<form class="search" method="get" id="search" action="<?php echo esc_url( home_url() ); ?>">

	<input type="text" class="searching" value="<?php the_search_query(); ?>" name="s" id="s" />
	<a class="btn btn-default" onclick="document.getElementById('search').submit()"><?php _e( 'search', 'non-cherry' ); ?></a>

</form>