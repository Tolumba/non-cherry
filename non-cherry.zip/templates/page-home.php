<?php

/**
 * Template Name: Home Page
 */

get_header(); ?>

	<?php get_template_part('template-parts/loops/loop-common'); ?>
	<?php get_template_part('template-parts/page-nav'); ?>
	
<?php get_footer(); ?>