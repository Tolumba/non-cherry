<div class="post-meta">
	<div class="info">
		<?php get_post_meta_info( 'author' ); ?>
		<?php get_post_meta_info( 'date' ); ?>
		<?php get_post_meta_info( 'comments' ); ?>
		<?php get_post_meta_info( 'categories' ); ?>
		<?php get_post_meta_info( 'tags' ); ?>
	</div>
</div>