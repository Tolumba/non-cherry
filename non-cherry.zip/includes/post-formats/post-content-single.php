<div class="post-content">

	<?php the_content(); ?>

</div>